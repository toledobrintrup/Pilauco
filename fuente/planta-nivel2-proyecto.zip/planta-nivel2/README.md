# Planta Nivel 2 — plano interactivo

## Qué hay aquí
- `web/index.html` — la página completa, autocontenida (un solo archivo). Se abre con doble clic o se sube a cualquier hosting estático.
- `web/template.html` — la misma página con el marcador `/*__DATA__*/` donde se inyectan los datos (lo usa el pipeline).
- `pipeline/` — scripts Python que reconstruyen la geometría desde el PDF original:
  1. `extract_walls.py`  → muros (polígonos) desde los vectores del PDF (`data/plano.pdf`)
  2. `rooms.py`          → detecta recintos cerrando puertas y ventanas
  3. `build_data.py`     → consolida recintos, muros, símbolos y cotas en `plan_data.json`
  4. `build_variant.py`  → ampliación de los 4 retranqueos (variant.json)
  5. `build_thick.py`    → muros 25/15 y V27 en línea de fachada (variant2.json = Versión 1)
  6. `build_v2.py`       → Versión 2: redistribución NW, hijos ×1,42, suite de visitas (versions.json)
  7. `build_svg.py`      → genera `svg_data.json` (paths SVG + tablas) que se inyecta en la página
- `data/` — resultados intermedios ya calculados, por si no quieres correr todo de nuevo.

## Regenerar la página
```bash
pip install pymupdf shapely opencv-python-headless numpy
cd pipeline
python build_v2.py && python build_svg.py
python - <<'PY'
s = open('../web/template.html').read(); d = open('svg_data.json').read()
open('../web/index.html', 'w').write(s.replace('/*__DATA__*/', d))
PY
```
Nota: los scripts esperan correr dentro de `pipeline/` con los JSON en el mismo directorio (copia `data/*.json` y `data/plano.pdf` allí, o ajusta las rutas).

## Publicar como sitio web
El archivo `web/index.html` no necesita servidor ni base de datos. Opciones sin programar:
- Netlify Drop (arrastrar la carpeta `web/`), GitHub Pages, Cloudflare Pages, Vercel — todas gratis para esto.
- Cualquier hosting propio: subir `index.html` a una carpeta pública.
La única dependencia externa son dos tipografías de Google Fonts (si no cargan, la página usa las del sistema).

## Coordenadas
Todo está en centímetros desde la esquina exterior noroeste del nivel 2 (x hacia el este, y hacia el sur).
Envolvente 1.790 × 2.177. Muros perimetrales 20 cm (cara exterior fija), tabiques 15 cm centrados en su eje.

## Nota sobre `data/plano.pdf`
El PDF original **no se incluye**: su viñeta lleva RUT, teléfono y correo. Para correr el
pipeline, copia tu propio `plano.pdf` (lámina L3 PLARQ2) dentro de `data/`.
