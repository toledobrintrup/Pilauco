import json, math
import numpy as np, cv2
from shapely.geometry import Polygon
from shapely.ops import unary_union

# --- scale & origin (PDF points -> cm) ---
X0, Y0 = 302.23, 717.19          # exterior faces top-left (pt)
S = (1317.24 - 302.23) / 1790.0  # pt per cm (fitted to TOTAL EXTERIOR 1790)
def to_cm(x, y):
    return ((x - X0) / S, (y - Y0) / S)

segs = json.load(open('w128.json'))
segs_cm = []
for x0, y0, x1, y1 in segs:
    if x0 > 1400: continue                     # title block junk
    a = to_cm(x0, y0); b = to_cm(x1, y1)
    segs_cm.append((a[0], a[1], b[0], b[1]))

PX = 4  # px per cm
W, H = 1790, 2177
img = np.zeros((H * PX + 2 * PX * 20, W * PX + 2 * PX * 20), np.uint8)
OFF = 20  # cm margin
def px(v): return int(round((v + OFF) * PX))
for x0, y0, x1, y1 in segs_cm:
    cv2.line(img, (px(x0), px(y0)), (px(x1), px(y1)), 255, 1)

# close tiny gaps (<= 2 cm) in the outlines
img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
# connected components of background (4-connectivity)
inv = (img == 0).astype(np.uint8)
# snap targets: exact x of vertical segs, exact y of horizontal segs
VX = sorted(set(round(s[0], 2) for s in segs_cm if abs(s[0] - s[2]) < 0.05))
HY = sorted(set(round(s[1], 2) for s in segs_cm if abs(s[1] - s[3]) < 0.05))
import bisect
def snap(v, arr, tol=1.2):
    i = bisect.bisect_left(arr, v)
    best = None
    for j in (i - 1, i):
        if 0 <= j < len(arr) and abs(arr[j] - v) <= tol:
            if best is None or abs(arr[j] - v) < abs(best - v): best = arr[j]
    return best if best is not None else v
n, lab, stats, cent = cv2.connectedComponentsWithStats(inv, connectivity=4)
dist = cv2.distanceTransform(inv, cv2.DIST_L2, 5)

walls, rooms, small = [], [], []
for i in range(1, n):
    x, y, w, h, area = stats[i]
    if x == 0 or y == 0 or x + w >= img.shape[1] or y + h >= img.shape[0]:
        continue  # exterior
    m = (lab == i)
    maxr = dist[m].max() / PX  # cm
    area_cm2 = area / PX / PX
    comp = m.astype(np.uint8)
    cnts, _ = cv2.findContours(comp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnt = max(cnts, key=cv2.contourArea)
    approx = cv2.approxPolyDP(cnt, 1.5, True)
    pts = [(p[0][0] / PX - OFF, p[0][1] / PX - OFF) for p in approx]
    # snap to 0.5 cm and collapse collinear
    pts = [(round(snap(a, VX), 1), round(snap(b, HY), 1)) for a, b in pts]
    clean = []
    for k in range(len(pts)):
        p0, p1, p2 = pts[k - 1], pts[k], pts[(k + 1) % len(pts)]
        if (p1[0] == p0[0] == p2[0]) or (p1[1] == p0[1] == p2[1]):
            continue
        clean.append(p1)
    entry = dict(pts=clean, area_m2=round(float(area_cm2) / 1e4, 3), maxr=round(float(maxr), 1),
                 bbox=[float(round(x / PX - OFF, 1)), float(round(y / PX - OFF, 1)), float(round(w / PX, 1)), float(round(h / PX, 1))])
    if maxr <= 12 and area_cm2 < 60000:
        walls.append(entry)
    elif area_cm2 < 10000:
        small.append(entry)
    else:
        rooms.append(entry)

print('walls', len(walls), 'rooms', len(rooms), 'small', len(small))
for r in rooms:
    print('ROOM', r['bbox'], r['area_m2'], 'maxr', r['maxr'], 'npts', len(r['pts']))
for r in small:
    print('SMALL', r['bbox'], r['area_m2'], 'maxr', r['maxr'])
json.dump(dict(walls=walls, rooms=rooms, small=small, segs=segs_cm), open('geom.json', 'w'))
