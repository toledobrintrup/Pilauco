"""Build the 'propuesta' variant: bring the four set-back facade stretches out to the facade line.
Coordinates in cm, origin = exterior NW corner. Facade lines: west x=0..18, east x=1772..1790."""
import json, math
from shapely.geometry import Polygon, box, Point, LineString, MultiPolygon
from shapely.ops import unary_union

D = json.load(open('plan_data.json'))
L = json.load(open('layers_cm.json'))
W, H = D['W'], D['H']

walls = [Polygon(w) for w in D['walls']]
wall_u = unary_union(walls)

# ---- the four interventions (marked in red by the user) ----
# each: remove box (set-back wall + returns), new facade wall box, windows (y ranges) that move to the facade,
# dividing-wall extensions, and rooms that gain the strip.
INT = [
    dict(id='O1', label='Oeste · Oficina 1 (parte baja) + Oficina 2', side='W',
         remove=box(18, 228, 68, 889), facade=box(0, 228, 18, 889),
         windows=[('V25', 247.2, 394.2), ('V26', 573, 871.2)],
         extend=[box(18, 405.8, 68, 419.8)],
         gains=[('OFICINA 1', box(18, 228, 68, 405.8)), ('OFICINA 2', box(18, 419.8, 68, 871.2))]),
    dict(id='O2', label='Oeste · Dormitorio 4', side='W',
         remove=box(18, 1285.1, 68, 1645), facade=box(0, 1271.1, 18, 1645),
         windows=[('V28', 1478.8, 1625.7)],
         extend=[box(18, 1271.1, 68, 1285.1)],
         gains=[('DORMITORIO 4', box(18, 1285.1, 68, 1645))]),
    dict(id='E1', label='Este · Suite + Baño 4', side='E',
         remove=box(1722, 71.7, 1772, 701.9), facade=box(1772, 71.7, 1790, 701.9),
         windows=[('V20', 90.6, 438.3), ('V19', 535.4, 682.4)],
         extend=[box(1722, 512.2, 1772, 526.2)],
         gains=[('DORMITORIO PRINCIPAL (SUITE)', box(1722, 71.7, 1772, 512.2)), ('BAÑO 4 (SUITE)', box(1722, 526.2, 1772, 701.9))]),
    dict(id='E2', label='Este · Dormitorio 2 (parte baja) + Baño 3 + Dormitorio 3 (parte alta)', side='E',
         remove=box(1722, 1136, 1772, 1780), facade=box(1772, 1136, 1790, 1780),
         windows=[('V18', 1155.3, 1302.3), ('V17', 1384, 1531), ('V16', 1613, 1760)],
         extend=[box(1722, 1313.8, 1772, 1327.8), box(1722, 1587.5, 1772, 1601.5)],
         gains=[('DORMITORIO 2', box(1722, 1136, 1772, 1313.8)), ('BAÑO 3', box(1722, 1327.8, 1772, 1587.5)), ('DORMITORIO 3', box(1722, 1601.5, 1772, 1780))]),
]

# exact window y-ranges from the wall caps (refine using existing openings list)
ops = D['openings']
def refine(y0, y1, x):
    best = None
    for o in ops:
        if abs(o['a'][0] - x) < 8 and abs(o['b'][0] - x) < 8:
            ya, yb = sorted([o['a'][1], o['b'][1]])
            if abs(ya - y0) < 6 and abs(yb - y1) < 6: best = (ya, yb)
    return best or (y0, y1)
for it in INT:
    xw = 62.5 if it['side'] == 'W' else 1727.5
    it['windows'] = [(n,) + refine(a, b, xw) for n, a, b in it['windows']]

removed = unary_union([it['remove'] for it in INT])
new_walls = wall_u.difference(removed)
added_parts = []
for it in INT:
    fac = it['facade']
    for n, a, b in it['windows']:
        fac = fac.difference(box(fac.bounds[0] - 1, a, fac.bounds[2] + 1, b))
    added_parts.append(fac)
    added_parts += it['extend']
added = unary_union(added_parts)
new_walls = unary_union([new_walls, added])
removed_walls = wall_u.intersection(removed)

def polys(geom):
    if geom.is_empty: return []
    if geom.geom_type == 'Polygon': return [geom]
    return [g for g in geom.geoms if g.geom_type == 'Polygon']
def ring(p, nd=1):
    return [(round(x, nd), round(y, nd)) for x, y in list(p.exterior.coords)[:-1]]
def clean(pts):
    out = []
    for p in pts:
        if out and abs(out[-1][0] - p[0]) < 0.3 and abs(out[-1][1] - p[1]) < 0.3: continue
        out.append(p)
    changed = True
    while changed and len(out) > 4:
        changed = False; res = []; n = len(out)
        for k in range(n):
            p0, p1, p2 = out[k - 1], out[k], out[(k + 1) % n]
            if (abs(p1[0] - p0[0]) < 0.3 and abs(p1[0] - p2[0]) < 0.3) or (abs(p1[1] - p0[1]) < 0.3 and abs(p1[1] - p2[1]) < 0.3):
                changed = True; continue
            res.append(p1)
        out = res
    return out

# ---- rooms ----
def despike(P):
    Q = P.buffer(1.2, join_style='mitre').buffer(-2.4, join_style='mitre').buffer(1.2, join_style='mitre').simplify(0.25)
    if Q.geom_type != 'Polygon': Q = max(Q.geoms, key=lambda g: g.area)
    return Q
rooms_old = []
for r in D['rooms']:
    r = dict(r); r['pts'] = clean(ring(despike(Polygon(r['pts'])))); rooms_old.append(metrics(r) if False else r)
rooms_new = []
gain_polys = []
for r in rooms_old:
    if r['name'] == 'NICHO / DUCTO':
        continue  # exterior set-back, not a room (dropped from both variants below)
    P = Polygon(r['pts'])
    gains = [(n, b) for it in INT for n, b in it['gains'] if n == r['name']]
    if gains:
        for n, b in gains:
            gain_polys.append(dict(room=r['name'], pts=ring(b), area=round(b.area / 1e4, 2)))
        P2 = unary_union([P] + [b for _, b in gains])
        # heal slivers (the old set-back wall band is inside the union now)
        P2 = despike(P2.buffer(0.3, join_style='mitre').buffer(-0.3, join_style='mitre'))
    else:
        P2 = P
    rooms_new.append(dict(name=r['name'], pts=clean(ring(P2))))

def metrics(r):
    P = Polygon(r['pts'])
    xs = [p[0] for p in r['pts']]; ys = [p[1] for p in r['pts']]
    r['area_m2'] = round(P.area / 1e4, 2)
    r['bbox'] = [round(min(xs), 1), round(min(ys), 1), round(max(xs), 1), round(max(ys), 1)]
    r['w'] = round(max(xs) - min(xs), 1); r['h'] = round(max(ys) - min(ys), 1)
    r['perim_m'] = round(P.length / 100, 2)
    c = P.centroid
    if not P.contains(c): c = P.representative_point()
    r['cx'] = round(c.x, 1); r['cy'] = round(c.y, 1)
    n = len(r['pts']); r['edges'] = []
    for k in range(n):
        a, b = r['pts'][k], r['pts'][(k + 1) % n]
        r['edges'].append(dict(a=list(a), b=list(b), len=round(math.hypot(b[0] - a[0], b[1] - a[1]), 1)))
    return r
rooms_new = [metrics(r) for r in rooms_new]
rooms_orig = [metrics(r) for r in rooms_old if r['name'] != 'NICHO / DUCTO']

# ---- windows symbols: translate the moved windows' drawing segments ----
MOVE = [(box(40, 240, 80, 880), -50), (box(40, 1279, 80, 1632), -50), (box(1715, 85, 1745, 690), 50), (box(1715, 1150, 1745, 1765), 50)]
def shift_items(items):
    out = []
    for it in items:
        pts = it[1:]
        dx = 0
        for b, d in MOVE:
            if all(b.contains(Point(p[0], p[1])) for p in pts): dx = d; break
        if dx: out.append([it[0]] + [[p[0] + dx, p[1]] for p in pts])
        else: out.append(it)
    return out
win_items_new = shift_items(D['sym']['windows'])
door_items_new = shift_items(D['sym']['doors'])  # window frames also live in this layer
# window id labels: move too
wins_new = []
for w in D['windows']:
    x, y = w['x'], w['y']
    for b, d in MOVE:
        if b.buffer(40).contains(Point(x, y)): x += d
    wins_new.append(dict(t=w['t'], x=round(x, 1), y=round(y, 1)))

# ---- summary ----
old_by = {r['name']: r for r in rooms_orig}
changes = []
for r in rooms_new:
    o = old_by[r['name']]
    if abs(r['area_m2'] - o['area_m2']) > 0.005 or abs(r['w'] - o['w']) > 0.5:
        strips = [dict(w=round(b.bounds[2] - b.bounds[0], 1), h=round(b.bounds[3] - b.bounds[1], 1)) for it in INT for n, b in it['gains'] if n == r['name']]
        changes.append(dict(name=r['name'], w0=o['w'], w1=r['w'], h0=o['h'], h1=r['h'], a0=o['area_m2'], a1=r['area_m2'], d=round(r['area_m2'] - o['area_m2'], 2), strips=strips))
tot0 = round(sum(r['area_m2'] for r in rooms_orig), 2); tot1 = round(sum(r['area_m2'] for r in rooms_new), 2)
new_wall_len = sum(max(p.bounds[2] - p.bounds[0], p.bounds[3] - p.bounds[1]) for part in added_parts for p in polys(part))
rem_wall_len = removed_walls.area / 18.0
summary = dict(tot0=tot0, tot1=tot1, gain=round(tot1 - tot0, 2), new_wall_m=round(new_wall_len / 100, 1), rem_wall_m=round(rem_wall_len / 100, 1),
               windows=[n for it in INT for n, a, b in it['windows']], interventions=[dict(id=it['id'], label=it['label'],
               windows=[dict(id=n, y0=round(a, 1), y1=round(b, 1), w=round(b - a, 1)) for n, a, b in it['windows']],
               gain=round(sum(b.area for _, b in it['gains']) / 1e4, 2)) for it in INT])

out = dict(walls_new=[clean(ring(p)) for p in polys(new_walls)], walls_added=[ring(p) for p in polys(added)],
           walls_removed=[ring(p) for p in polys(removed_walls)], rooms_new=rooms_new, rooms_orig=rooms_orig,
           gains=gain_polys, win_items_new=win_items_new, door_items_new=door_items_new, windows_new=wins_new, changes=changes, summary=summary)
json.dump(out, open('variant.json', 'w'), ensure_ascii=False)
print('walls new', len(out['walls_new']), 'added', len(out['walls_added']), 'removed', len(out['walls_removed']))
for c in changes: print(f"{c['name']:30s} {c['w0']:6.1f}->{c['w1']:6.1f}  {c['a0']:6.2f}->{c['a1']:6.2f}  +{c['d']}")
print('total', tot0, '->', tot1, 'gain', summary['gain'], 'new wall m', summary['new_wall_m'], 'removed wall m', summary['rem_wall_m'])
for it in summary['interventions']: print(it)
