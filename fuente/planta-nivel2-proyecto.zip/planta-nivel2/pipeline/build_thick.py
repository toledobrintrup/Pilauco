"""Second design pass on top of variant.json:
 1. close the last set-back (Baño Visitas / V27) -> flat west facade
 2. re-thicken walls: perimeter 18 -> 20 cm (exterior face fixed), interior 14 -> 15 cm (centred)
 3. regenerate window symbols in the new wall thickness
Output: variant2.json with the same shape as variant.json."""
import json, math
from shapely.geometry import Polygon, box, Point, LineString
from shapely.ops import unary_union

T_EXT, T_INT = 25.0, 15.0
v = json.load(open('variant.json'))
walls = unary_union([Polygon(w) for w in v['walls_new']])
rooms = {r['name']: Polygon(r['pts']) for r in v['rooms_new']}

# ---- 1. close Baño 2 set-back, V27 to the facade line ----
rm = box(18, 1093.1, 68, 1271.1)
walls = walls.difference(rm)
walls = unary_union([walls, box(0, 1093.1, 18, 1271.1).difference(box(-1, 1112.6, 19, 1259.6))])
walls = unary_union([walls, box(18, 871.2, 68, 885.1)])   # Oficina 2 / Baño 2 wall reaches the facade
rooms['BAÑO 2'] = unary_union([rooms['BAÑO 2'], rm, box(18, 885.1, 68, 889.1)]).buffer(0.3, join_style='mitre').buffer(-0.3, join_style='mitre')

def ring(p, nd=1):
    if p.geom_type != 'Polygon': p = max(p.geoms, key=lambda g: g.area)
    return [(round(x, nd), round(y, nd)) for x, y in list(p.exterior.coords)[:-1]]
def despike(P):
    Q = P.buffer(1.6, join_style='mitre').buffer(-3.2, join_style='mitre').buffer(1.6, join_style='mitre').simplify(0.25)
    if Q.geom_type != 'Polygon': Q = max(Q.geoms, key=lambda g: g.area)
    return Q
def orthogonalize(pts):
    out = list(pts)
    for i in range(len(out)):
        a, b = out[i - 1], out[i]
        dx, dy = abs(a[0] - b[0]), abs(a[1] - b[1])
        if dx > 0.01 and dy > 0.01:
            if dx < dy: out[i] = (a[0], b[1])
            else: out[i] = (b[0], a[1])
    return out
def clean(pts):
    pts = orthogonalize(pts)
    out = []
    for p in pts:
        if out and abs(out[-1][0] - p[0]) < 0.3 and abs(out[-1][1] - p[1]) < 0.3: continue
        out.append(p)
    changed = True
    while changed and len(out) > 4:
        changed = False; res = []; n = len(out)
        for k in range(n):
            p0, p1, p2 = out[k - 1], out[k], out[(k + 1) % n]
            if (abs(p1[0] - p0[0]) < 0.3 and abs(p1[0] - p2[0]) < 0.3) or (abs(p1[1] - p0[1]) < 0.3 and abs(p1[1] - p2[1]) < 0.3):
                changed = True; continue
            res.append(p1)
        out = res
    return out

# ---- 2. per-edge wall probing ----
def thickness(p, n):
    probe = LineString([(p[0] + n[0] * 0.05, p[1] + n[1] * 0.05), (p[0] + n[0] * 45, p[1] + n[1] * 45)])
    inter = probe.intersection(walls)
    pieces = [inter] if inter.geom_type == 'LineString' else [g for g in getattr(inter, 'geoms', []) if g.geom_type == 'LineString']
    start = Point(probe.coords[0])
    best = None
    for g in pieces:
        dd = start.distance(g)
        if dd < 1.0 and (best is None or dd < best[0]): best = (dd, g.length)
    return (best[0], best[1]) if best else (0.0, 0.0)

strips, win_syms, remove_boxes = [], [], []
new_rooms = {}
rooms_union = unary_union(list(rooms.values()))
for name, P in rooms.items():
    pts = clean(ring(despike(P)))
    P = Polygon(pts)
    n = len(pts)
    deltas = []
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        vert = abs(a[0] - b[0]) < 0.01
        L = abs(b[1] - a[1]) if vert else abs(b[0] - a[0])
        mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        # outward normal
        nrm = (1, 0) if vert else (0, 1)
        if P.contains(Point(mid[0] + nrm[0] * 1.5, mid[1] + nrm[1] * 1.5)): nrm = (-nrm[0], -nrm[1])
        # samples along the edge
        lo, hi = (min(a[1], b[1]), max(a[1], b[1])) if vert else (min(a[0], b[0]), max(a[0], b[0]))
        c = a[0] if vert else a[1]          # constant coordinate of the edge line
        samples = []
        s = lo + 0.5
        while s < hi:
            p = (c, s) if vert else (s, c)
            gp, t = thickness(p, nrm)
            samples.append((s, t, gp))
            s += 1.0
        def cls(sample):
            s_, t, gp = sample
            if t < 5: return ('gap', 0.0)
            p = (c, s_) if vert else (s_, c)
            beyond = Point(p[0] + nrm[0] * (gp + t + 2.5), p[1] + nrm[1] * (gp + t + 2.5))
            if rooms_union.contains(beyond): return ('int', max(0.0, (T_INT - t) / 2))
            return ('ext', max(0.0, T_EXT - t))
        classes = [cls(sm) for sm in samples]
        wall_cls = [k for k, d in classes if k != 'gap']
        if wall_cls:
            major = max(set(wall_cls), key=wall_cls.count)
            ds = sorted(d for k, d in classes if k == major); d_edge = ds[len(ds) // 2]
            gs = sorted(gp for (k, d), (_, _, gp) in zip(classes, samples) if k == major); g_edge = gs[len(gs) // 2]
        else:
            major, d_edge, g_edge = 'gap', 0.0, 0.0
        # effective shift of the room face: wall face is at c + nrm*g_edge; new face = wall face - nrm*d_edge
        d_eff = d_edge - g_edge
        deltas.append((major, d_eff, nrm))
        # runs of wall samples -> strips ; runs of gaps on exterior edges -> window symbols
        run_start, run_kind = None, None
        def flush(s0, s1, kind):
            if kind is None: return
            s0e, s1e = s0 - 0.5, s1 + 0.5
            if kind != 'gap':
                d = d_edge
                if d <= 0: return
                if vert:   # strip: from the wall face (+0.6 overlap into the wall) to the new room face
                    x0, x1 = sorted([c + nrm[0] * (g_edge + 0.6), c - nrm[0] * d_eff]); strips.append(box(x0, s0e, x1, s1e))
                else:
                    y0, y1 = sorted([c + nrm[1] * (g_edge + 0.6), c - nrm[1] * d_eff]); strips.append(box(s0e, y0, s1e, y1))
            elif major == 'ext':
                # window: outer face = c + nrm*18 (old exterior thickness), inner face = c - nrm*d_edge
                outer = c + nrm[0] * (g_edge + 18) if vert else c + nrm[1] * (g_edge + 18)
                inner = c - nrm[0] * d_eff if vert else c - nrm[1] * d_eff
                if vert:
                    x0, x1 = sorted([outer, inner]); win_syms.append(dict(x0=x0, y0=s0e, x1=x1, y1=s1e, vert=True))
                    remove_boxes.append(box(x0 - 1.5, s0e - 1.5, x1 + 1.5, s1e + 1.5))
                else:
                    y0, y1 = sorted([outer, inner]); win_syms.append(dict(x0=s0e, y0=y0, x1=s1e, y1=y1, vert=False))
                    remove_boxes.append(box(s0e - 1.5, y0 - 1.5, s1e + 1.5, y1 + 1.5))
        for (s, t, gp), (k, d) in zip(samples, classes):
            kind = 'gap' if k == 'gap' else 'wall'
            if kind != run_kind:
                if run_kind is not None: flush(run_start, prev_s, run_kind)
                run_start, run_kind = s, kind
            prev_s = s
        if run_kind is not None: flush(run_start, prev_s, run_kind)
    # new polygon: shift each edge line inward by its delta, intersect consecutive lines
    lines = []
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        vert = abs(a[0] - b[0]) < 0.01
        major, d, nrm = deltas[i]
        c = a[0] if vert else a[1]
        lines.append((vert, c - (nrm[0] if vert else nrm[1]) * d))
    newpts = []
    for i in range(n):
        v0, c0 = lines[i - 1]; v1, c1 = lines[i]
        if v0 == v1: raise SystemExit(f'non-alternating edges in {name}')
        x = c0 if v0 else c1; y = c1 if v0 else c0
        newpts.append((round(x, 2), round(y, 2)))
    new_rooms[name] = Polygon(newpts)

new_walls = unary_union([walls] + strips)
def polys(geom):
    if geom.is_empty: return []
    if geom.geom_type == 'Polygon': return [geom]
    return [g for g in geom.geoms if g.geom_type == 'Polygon']

# ---- 3. window symbols: drop old frame lines inside the new exterior wall bands, regenerate ----
rmv = unary_union(remove_boxes + [box(40, 1095, 80, 1275)])   # + old V27 symbol in the closed set-back
def keep(it):
    return not all(rmv.contains(Point(p[0], p[1])) for p in it[1:])
doors = [it for it in v['door_items_new'] if keep(it)]
wins = [it for it in v['win_items_new'] if keep(it)]
for w in win_syms:
    x0, y0, x1, y1 = w['x0'], w['y0'], w['x1'], w['y1']
    wins.append(['l', [x0, y0], [x1, y0]]); wins.append(['l', [x1, y0], [x1, y1]]); wins.append(['l', [x1, y1], [x0, y1]]); wins.append(['l', [x0, y1], [x0, y0]])
    if w['vert']: cx = (x0 + x1) / 2; wins.append(['l', [cx, y0], [cx, y1]])
    else: cy = (y0 + y1) / 2; wins.append(['l', [x0, cy], [x1, cy]])
windows_new = []
for wl in v['windows_new']:
    wl = dict(wl)
    if wl['t'] == 'V27': wl['x'] = 20.8
    windows_new.append(wl)

# ---- metrics ----
def metrics(name, P):
    pts = clean(ring(P, 2))
    P = Polygon(pts)
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    r = dict(name=name, pts=[(round(x, 1), round(y, 1)) for x, y in pts], area_m2=round(P.area / 1e4, 2),
             bbox=[round(min(xs), 1), round(min(ys), 1), round(max(xs), 1), round(max(ys), 1)],
             w=round(max(xs) - min(xs), 1), h=round(max(ys) - min(ys), 1), perim_m=round(P.length / 100, 2))
    c = P.centroid
    if not P.contains(c): c = P.representative_point()
    r['cx'] = round(c.x, 1); r['cy'] = round(c.y, 1)
    n = len(pts); r['edges'] = []
    for k in range(n):
        a, b = pts[k], pts[(k + 1) % n]
        r['edges'].append(dict(a=[round(a[0], 1), round(a[1], 1)], b=[round(b[0], 1), round(b[1], 1)], len=round(math.hypot(b[0] - a[0], b[1] - a[1]), 1)))
    return r
rooms_out = [metrics(n, P) for n, P in new_rooms.items()]

out = dict(v)
def wall_rings(p):
    q = p.simplify(0.05)
    pts = [(round(x, 1), round(y, 1)) for x, y in list(q.exterior.coords)[:-1]]
    P = Polygon(pts)
    if P.is_valid: return [pts]
    fixed = P.buffer(0)
    return [[(round(x, 1), round(y, 1)) for x, y in list(g.exterior.coords)[:-1]] for g in polys(fixed) if g.area > 1]
new_walls = unary_union([walls] + strips).buffer(0)
wl = []
for p in polys(new_walls): wl += wall_rings(p)
out.update(walls_new=wl, rooms_new=rooms_out, win_items_new=wins, door_items_new=doors,
           windows_new=windows_new, walls_added=[], walls_removed=[], gains=[], changes=[])
json.dump(out, open('variant2.json', 'w'), ensure_ascii=False)

# ---- report ----
print('strips', len(strips), 'window symbols', len(win_syms), 'walls', len(out['walls_new']))
for r in rooms_out: print(f"{r['name']:24s} {r['w']:6.1f} x {r['h']:6.1f}  {r['area_m2']:6.2f} m2  pts={len(r['pts'])}")
print('total', round(sum(r['area_m2'] for r in rooms_out), 2))
# thickness audit: sample new walls from every new room edge
import collections
walls = new_walls
aud = collections.Counter()
for r in rooms_out:
    P = Polygon(r['pts']); n = len(r['pts'])
    for i in range(n):
        a, b = r['pts'][i], r['pts'][(i + 1) % n]; vert = abs(a[0] - b[0]) < 0.01
        mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2); nrm = (1, 0) if vert else (0, 1)
        if P.contains(Point(mid[0] + nrm[0] * 1.5, mid[1] + nrm[1] * 1.5)): nrm = (-nrm[0], -nrm[1])
        lo, hi = (min(a[1], b[1]), max(a[1], b[1])) if vert else (min(a[0], b[0]), max(a[0], b[0])); c = a[0] if vert else a[1]
        s = lo + 2
        while s < hi - 1:
            p = (c, s) if vert else (s, c); gp, t = thickness(p, nrm)
            if t >= 5: aud[round(t * 2) / 2] += 1
            s += 5
print('thickness audit (cm: samples):', sorted(aud.items()))
