import json, math, bisect
from shapely.geometry import Polygon, Point, LineString
from shapely.ops import unary_union

g = json.load(open('geom.json'))
rooms_raw = json.load(open('rooms_raw.json'))
L = json.load(open('layers_cm.json'))
T = json.load(open('terrace_layers.json'))
words = json.load(open('words.json'))
openings = json.load(open('openings.json'))

X0, Y0 = 302.23, 717.19
S = (1317.24 - 302.23) / 1790.0
def to_cm(x, y): return ((x - X0) / S, (y - Y0) / S)

segs = g['segs']
VX = sorted(set(round(s[0], 2) for s in segs if abs(s[0] - s[2]) < 0.05))
HY = sorted(set(round(s[1], 2) for s in segs if abs(s[1] - s[3]) < 0.05))
def snap(v, arr, tol=1.5):
    i = bisect.bisect_left(arr, v); best = None
    for j in (i - 1, i):
        if 0 <= j < len(arr) and abs(arr[j] - v) <= tol:
            if best is None or abs(arr[j] - v) < abs(best - v): best = arr[j]
    return best if best is not None else v

def clean_poly(pts):
    pts = [(round(snap(a, VX), 1), round(snap(b, HY), 1)) for a, b in pts]
    # force orthogonality: each consecutive pair must share x or y; fix tiny jogs
    out = []
    for p in pts:
        if out and abs(out[-1][0] - p[0]) < 0.6 and abs(out[-1][1] - p[1]) < 0.6: continue
        out.append(p)
    changed = True
    while changed:
        changed = False
        res = []
        n = len(out)
        for k in range(n):
            p0, p1, p2 = out[k - 1], out[k], out[(k + 1) % n]
            if (abs(p1[0] - p0[0]) < 0.6 and abs(p1[0] - p2[0]) < 0.6) or (abs(p1[1] - p0[1]) < 0.6 and abs(p1[1] - p2[1]) < 0.6):
                changed = True; continue
            res.append(p1)
        out = res
    return out

# ---- rooms ----
rooms = []
for r in rooms_raw:
    poly = clean_poly(r['pts'])
    rooms.append(dict(pts=poly))

# merge Baño 4 (two parts split by the 166 passage at x=1365)
def bbox(pts):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    return (min(xs), min(ys), max(xs), max(ys))
b4 = [r for r in rooms if 500 < bbox(r['pts'])[1] < 540 and bbox(r['pts'])[0] > 1000 and bbox(r['pts'])[3] < 900]
if len(b4) == 2:
    u = unary_union([Polygon(r['pts']).buffer(0.05) for r in b4] + [Polygon([(1358.1, 632.2), (1372.1, 632.2), (1372.1, 798.2), (1358.1, 798.2)])]).buffer(-0.05)
    u = u.simplify(0.3)
    pts = [(round(x, 1), round(y, 1)) for x, y in list(u.exterior.coords)[:-1]]
    for r in b4: rooms.remove(r)
    rooms.append(dict(pts=clean_poly(pts)))

# ---- labels ----
labels = {}
for w in words:
    t = w['t']
    if w['x'] > 1480: continue
    if t in ('OFICINA 1', 'OFICINA 2', 'WALKING CLOSET', 'DORMITORIO PRINCIPAL', 'BAÑO  4', 'BAÑO  2', 'BAÑO  3',
             'DORMITORIO 2', 'DORMITORIO 3', 'DORMITORIO 4', 'ESTAR 2', 'TERRAZA'):
        cx, cy = to_cm(w['x'], w['y'])
        labels.setdefault(t.replace('  ', ' '), []).append((cx, cy))
names = {'DORMITORIO PRINCIPAL': 'DORMITORIO PRINCIPAL (SUITE)', 'BAÑO 4': 'BAÑO 4 (SUITE)'}
wc_i = 0
for r in rooms:
    P = Polygon(r['pts'])
    r['name'] = None
    for t, pts in labels.items():
        for (cx, cy) in pts:
            if P.contains(Point(cx, cy)):
                r['name'] = names.get(t, t)
for r in rooms:
    b = bbox(r['pts'])
    if r['name'] is None:
        if b[0] > 1700: r['name'] = 'NICHO / DUCTO'
        elif b[0] > 1000 and b[1] > 1300 and b[3] < 1600: r['name'] = 'HALL DORMITORIOS'
        else: r['name'] = 'SIN NOMBRE'
# distinguish walking closets by neighbour
for r in rooms:
    if r['name'] == 'WALKING CLOSET':
        b = bbox(r['pts'])
        if b[1] < 100 and b[0] > 600: r['name'] = 'WALKING CLOSET (SUITE)'
        elif b[1] < 100: r['name'] = 'WALKING CLOSET (HALL)'
        elif b[1] < 1000: r['name'] = 'WALKING CLOSET (DORM. 2)'
        else: r['name'] = 'WALKING CLOSET (DORM. 3)'
    if r['name'] == 'ESTAR 2': r['name'] = 'ESTAR 2 + ESCALERA'

# ---- metrics ----
for r in rooms:
    P = Polygon(r['pts'])
    r['area_m2'] = round(P.area / 1e4, 2)
    b = bbox(r['pts'])
    r['bbox'] = [round(v, 1) for v in b]
    r['w'] = round(b[2] - b[0], 1); r['h'] = round(b[3] - b[1], 1)
    edges = []
    n = len(r['pts'])
    for k in range(n):
        a, c = r['pts'][k], r['pts'][(k + 1) % n]
        ln = math.hypot(c[0] - a[0], c[1] - a[1])
        edges.append(dict(a=a, b=c, len=round(ln, 1)))
    r['edges'] = edges
    r['perim_m'] = round(P.length / 100, 2)
    r['cx'] = round(P.representative_point().x, 1); r['cy'] = round(P.representative_point().y, 1)
    # centroid of largest inscribed rectangle-ish: use centroid, fallback representative
    c = P.centroid
    if P.contains(c): r['cx'], r['cy'] = round(c.x, 1), round(c.y, 1)

rooms.sort(key=lambda r: (r['bbox'][1] // 300, r['bbox'][0]))
for r in rooms:
    print(f"{r['name']:32s} {r['w']:6.1f} x {r['h']:6.1f}  {r['area_m2']:6.2f} m2  npts={len(r['pts'])}")

# ---- walls ----
walls = [clean_poly(w['pts']) for w in g['walls']]

# ---- openings (doors/windows) ----
def opening_type(o):
    seg = LineString([o['a'], o['b']]).buffer(6)
    win = 0
    for k in ['(0.28, 0.53)', '(0.43, 0.5)']:
        for it in L.get(k, []):
            if it[0] == 'l' and seg.contains(LineString([it[1], it[2]]).representative_point()): win += 1
    if win >= 2: return 'window'
    return 'door' if o['gap'] <= 130 else 'passage'
ops = []
for o in openings:
    if o['gap'] < 30: continue
    ops.append(dict(a=[round(v, 1) for v in o['a']], b=[round(v, 1) for v in o['b']], gap=o['gap'], type=opening_type(o)))
for s in json.load(open('stubs.json')):
    if s['gap'] >= 30:
        ops.append(dict(a=[round(v, 1) for v in s['a']], b=[round(v, 1) for v in s['b']], gap=s['gap'], type='door'))
# window ids from text (V12..V28, P6+V23)
wins = []
for w in words:
    t = w['t']
    if (t.startswith('V') and t[1:].isdigit()) or t.startswith('P6'):
        cx, cy = to_cm(w['x'], w['y'])
        if -100 < cx < 1900 and -100 < cy < 2300: wins.append(dict(t=t, x=round(cx, 1), y=round(cy, 1)))

# ---- symbol layers (doors, windows, furniture) ----
def conv_items(items):
    out = []
    for it in items:
        if it[0] == 'l': out.append(['l', [round(v, 1) for v in it[1]], [round(v, 1) for v in it[2]]])
        elif it[0] == 'c': out.append(['c'] + [[round(v, 1) for v in p] for p in it[1:]])
        elif it[0] == 're': out.append(['re', [round(v, 1) for v in it[1]], [round(v, 1) for v in it[2]]])
        elif it[0] == 'qu': out.append(['qu'] + [[round(v, 1) for v in p] for p in it[1:]])
    return out
sym = dict(
    doors=conv_items(L.get('(0.23, 0.53)', [])),
    windows=conv_items(L.get('(0.28, 0.53)', []) + L.get('(0.43, 0.5)', [])),
    furniture=conv_items(L.get('(0.57, 0.38)', []) + L.get('(0.57, 0.41)', [])),
    stairs=conv_items(L.get('(0.01, 0.3)', [])),
)
# ---- original architect dimension texts (inside plan + perimeter chains) ----
cotas = []
for w in words:
    t = w['t'].replace('.', '')
    if not t.isdigit(): continue
    if w['size'] > 8: continue           # axis labels
    cx, cy = to_cm(w['x'], w['y'])
    if -260 < cx < 2050 and -1000 < cy < 2450:
        rot = 0 if abs(w['dir'][0]) > 0.5 else (-90 if w['dir'][1] < 0 else 90)
        cotas.append(dict(t=w['t'], x=round(cx, 1), y=round(cy, 1), rot=rot))
# dimension lines layer (0.03 black) inside plan - merge tiny collinear pieces
dimlines = []
for it in L.get('(0.03, 0.0)', []):
    if it[0] == 'l':
        (x0, y0), (x1, y1) = it[1], it[2]
        if math.hypot(x1 - x0, y1 - y0) > 3:
            dimlines.append([round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1)])
# axes (0.99 black) and labels
axes = []
for it in L.get('(0.99, 0.0)', []):
    if it[0] == 'l':
        (x0, y0), (x1, y1) = it[1], it[2]
        axes.append([round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1)])
axis_labels = []
for w in words:
    if w['size'] > 12 and len(w['t']) <= 2 and w['x'] < 1480:
        cx, cy = to_cm(w['x'], w['y'])
        axis_labels.append(dict(t=w['t'], x=round(cx, 1), y=round(cy, 1)))

terrace = dict(
    railing=[[[round(v) for v in a], [round(v) for v in b]] for a, b in T["(0.71, 0.5, '[] 0')"]],
    columns=[[590, -205, 660, -135], [590, -785, 660, -715]],
    outline=[[40, -785], [660, -785], [660, 0], [40, 0]],
)
data = dict(W=1790, H=2177, rooms=rooms, walls=walls, openings=ops, windows=wins, sym=sym,
            cotas=cotas, dimlines=dimlines, axes=axes, axis_labels=axis_labels, terrace=terrace)
json.dump(data, open('plan_data.json', 'w'))
print('walls', len(walls), 'openings', len(ops), 'cotas', len(cotas), 'dimlines', len(dimlines),
      'furniture', len(sym['furniture']), 'doors', len(sym['doors']), 'windows', len(sym['windows']))
