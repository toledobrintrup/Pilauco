"""Version 2 on top of variant2.json (= Version 1, walls 20/15).
North-west: Oficinas out; Dormitorio Matrimonial (W), Baño Matrimonial (SW, door to the Mini Hall), Mini Hall down to
the E1 line with its own entrance door, WKC Maggie in the old suite bedroom, WKC Gabriel unchanged.
East: the old suite bathroom disappears; Dormitorio Anto and Dormitorio Pepe modules scale by the same factor k in
depth (closets included), Baño Hijos + hall block keeps its size and slides up."""
import json, math
from shapely.geometry import Polygon, box, Point, LineString
from shapely.ops import unary_union
from shapely.affinity import translate

v1 = json.load(open('variant2.json'))
D = json.load(open('plan_data.json'))
walls = unary_union([Polygon(w) for w in v1['walls_new']])
rooms1 = {r['name']: Polygon(r['pts']) for r in v1['rooms_new']}
T = 15.0

# ---- key lines (cm), from the V1 geometry ----
FX, FY = 20.1, 20.1                 # facade inner faces (west, north)
EFX = 1770.0                        # east facade inner face
CORR = (367.4, 382.4)               # old corridor wall (x)
OF12 = (405.3, 420.3)               # old Oficina 1/2 wall (y)  == F2 axis
GW = (645.6, 660.7)                 # WKC Gabriel west wall (x)
GE = (999.6, 1014.6)                # WKC Gabriel east wall / Family Room east wall (x)
VEST = (816.8, 831.9)               # old closet / vestibule wall (x)
HALLS = (764.1, 779.1)              # old Mini Hall south wall (y)
OB = (870.6, 885.7)                 # Baño Visitas north wall (y) == E1 axis
SUITE_S = (511.7, 526.7)            # WKC Maggie / (old bath) wall (y) == F1 axis
NEW_Y = 557.0                       # estimated bedroom / bath wall axis (from the sketch)
NB = (NEW_Y - T / 2, NEW_Y + T / 2)
SOUTH_E = 2029.2                    # inner face of the south facade wall in the east zone

# ================= NORTH-WEST =================
removed = unary_union([
    box(CORR[0], FY, CORR[1], HALLS[0]),          # corridor wall above the old hall south wall
    box(FX, OF12[0], CORR[1], OF12[1]),           # Oficina 1/2 wall
    box(VEST[0], OF12[1], VEST[1], HALLS[0]),     # closet / vestibule wall
    box(CORR[0], HALLS[0], GE[0], HALLS[1]),      # old Mini Hall south wall (whole length, incl. its door)
    box(CORR[0], HALLS[1], CORR[1], OB[0]),       # corridor wall stub between the old hall wall and E1 (bath notch)
])
walls = walls.difference(removed)
added = [
    box(GW[0], OF12[1], GW[1], OB[1]),            # (a) WKC Gabriel west line continued south to the E1 wall
    box(FX, NB[0], GW[0], NB[1]),                 # (b) bedroom / bath wall, axis estimated at y = 557
    box(CORR[0], OB[0], GE[1], OB[1]),            # (c) E1 wall: bath + Mini Hall south wall, joins the Family Room east wall
]
walls = unary_union([walls] + added)
DOOR_A = (430.0, 520.0)      # bedroom door, wall (a), y range, P 90 (from the Mini Hall)
DOOR_BATH = (600.0, 680.0)   # bath door, wall (a), y range, P 80 (from the Mini Hall)
DOOR_HALL = (800.0, 890.0)   # Mini Hall entrance, wall (c), x range, P 90 (from the Family Room)
walls = walls.difference(box(GW[0] - 1, DOOR_A[0], GW[1] + 1, DOOR_A[1]))
walls = walls.difference(box(GW[0] - 1, DOOR_BATH[0], GW[1] + 1, DOOR_BATH[1]))
walls = walls.difference(box(DOOR_HALL[0], OB[0] - 1, DOOR_HALL[1], OB[1] + 1))

# ================= GUEST SUITE =================
# the old Baño Visitas band (347.3 x 384.9) is split by a N-S partition 180 cm from the facade:
# west = Baño Visitas 180 x 385 (window V27), east = vestibule 152.3 x 385 (closet + cot), reached through the
# existing sliding door in the C2 wall; the bath opens off the vestibule. No structural line is touched.
GB = (OB[1], 1270.6)                   # Baño Visitas band (y): E1 inner face -> C2 wall face
GP = (FX + 180.0, FX + 180.0 + T)      # new partition (x)
DOOR_GB = (1180.0, 1255.0)             # bath door in the new partition, y range, P 75
walls = unary_union([walls, box(GP[0], GB[0], GP[1], GB[1])])
walls = walls.difference(box(GP[0] - 1, DOOR_GB[0], GP[1] + 1, DOOR_GB[1]))

# ================= EAST =================
# modules (V1): Anto band 885.7-1313.3 (427.6), hall+Baño Hijos block 1313.3-1602 (288.7 incl. both walls), Pepe band 1602-2029.2 (427.2)
A0, A1 = 885.7, 1313.3
B0, B1 = 1313.3, 1602.0
P0, P1 = 1602.0, SOUTH_E
avail = SOUTH_E - SUITE_S[1]
k = (avail - (B1 - B0)) / ((A1 - A0) + (P1 - P0))
nA1 = SUITE_S[1] + (A1 - A0) * k          # Anto south face
nB0, nB1 = nA1, nA1 + (B1 - B0)           # block
nP0 = nB1                                 # Pepe north face
shift_block = nB0 - B0
dA = (1199.3 - 885.7) * k                 # WKC Anto depth (was 313.6)
dP = (2029.2 - 1716.0) * k                # WKC Pepe depth (was 313.2)
print(f'k = {k:.4f}  Anto {SUITE_S[1]}-{nA1:.1f}  block {nB0:.1f}-{nB1:.1f}  Pepe {nP0:.1f}-{P1}  shift block {shift_block:.1f}')

# take the hall block walls (incl. pocket-door extensions 100 cm above/below) from V1 and slide them
block_src = box(GE[0] - 0.1, 1214.4, EFX, 1700.9)
block_walls = translate(walls.intersection(block_src), yoff=shift_block)
# wipe the east zone and rebuild
walls = walls.difference(box(GE[0] - 0.1, SUITE_S[1] - 0.1, 1790.1, SOUTH_E + 0.1))
east = [
    box(GE[0], SUITE_S[1] - 0.1, GE[1], SOUTH_E + 0.1),                        # west column (Family Room / Mini Hall side)
    box(EFX, SUITE_S[1] - 0.1, 1790.0, SOUTH_E + 0.1),                          # east facade
    box(GE[0], SUITE_S[0], EFX, SUITE_S[1]),                                    # WKC Maggie / Anto wall (existing line)
    # WKC Anto: east wall + south wall
    box(1281.6, SUITE_S[1], 1296.6, SUITE_S[1] + dA + T), box(GE[1], SUITE_S[1] + dA, 1296.6, SUITE_S[1] + dA + T),
    # WKC Pepe: east wall + north wall
    box(1281.6, SOUTH_E - dP - T, 1296.6, SOUTH_E), box(GE[1], SOUTH_E - dP - T, 1296.6, SOUTH_E - dP),
    block_walls,
]
walls = unary_union([walls] + east)
# closet doors (same x as V1)
walls = walls.difference(box(1111.7, SUITE_S[1] + dA - 1, 1196.7, SUITE_S[1] + dA + T + 1))
walls = walls.difference(box(1115.0, SOUTH_E - dP - T - 1, 1190.0, SOUTH_E - dP + 1))
# east facade windows: V19 stays, V18/V17/V16 follow their rooms (same width 147)
def fmap_anto(y): return SUITE_S[1] + (y - A0) * k
def fmap_pepe(y): return SOUTH_E - (SOUTH_E - y) * k
WIN = dict(V19=(535.4, 682.4))
c18 = fmap_anto((1155.3 + 1302.3) / 2); WIN['V18'] = (c18 - 73.5, c18 + 73.5)
c17 = (1384.0 + 1531.0) / 2 + shift_block; WIN['V17'] = (c17 - 73.5, c17 + 73.5)
c16 = fmap_pepe((1613.0 + 1760.0) / 2); WIN['V16'] = (c16 - 73.5, c16 + 73.5)
for n, (a, b) in WIN.items(): walls = walls.difference(box(EFX - 1, a, 1790 + 1, b))

def polys(g):
    if g.is_empty: return []
    return [g] if g.geom_type == 'Polygon' else [x for x in g.geoms if x.geom_type == 'Polygon']
def ring(p):
    q = p.simplify(0.05)
    pts = [(round(x, 1), round(y, 1)) for x, y in list(q.exterior.coords)[:-1]]
    if Polygon(pts).is_valid: return [pts]
    return [[(round(x, 1), round(y, 1)) for x, y in list(g.exterior.coords)[:-1]] for g in polys(Polygon(pts).buffer(0)) if g.area > 1]
walls_out = []
for p in polys(walls.buffer(0)): walls_out += ring(p)

# ================= ROOMS =================
rooms2 = {}
keep = ('WALKING CLOSET (SUITE)', 'DORMITORIO 4')
for n in keep: rooms2[n] = rooms1[n]
rooms2['BAÑO 2'] = box(FX, GB[0], GP[0], GB[1])
rooms2['VESTÍBULO VISITAS'] = box(GP[1], GB[0], CORR[0], GB[1])
rooms2['DORMITORIO MATRIMONIAL'] = box(FX, FY, GW[0], NB[0])
rooms2['BAÑO MATRIMONIAL'] = box(FX, NB[1], GW[0], OB[0])
rooms2['MINI HALL'] = box(GW[1], OF12[1], GE[0], OB[0])
rooms2['WKC MAGGIE'] = box(GE[1], FY, EFX, SUITE_S[0])
fr = [(x, (OB[1] if abs(y - 779.1) < 0.2 else y)) for x, y in rooms1['ESTAR 2 + ESCALERA'].exterior.coords[:-1]]
rooms2['ESTAR 2 + ESCALERA'] = Polygon(fr)
# east
yA = SUITE_S[1]; yAc = yA + dA          # Anto: top, closet bottom
rooms2['WALKING CLOSET (DORM. 2)'] = box(GE[1], yA, 1281.6, yAc)
pk = 1213.8 + shift_block               # pocket thickening starts (Anto side)
rooms2['DORMITORIO 2'] = Polygon([(1296.6, yA), (EFX, yA), (EFX, nA1), (1024.2, nA1), (1024.2, pk), (GE[1], pk), (GE[1], yAc + T), (1296.6, yAc + T)])
rooms2['HALL DORMITORIOS'] = translate(rooms1['HALL DORMITORIOS'], yoff=shift_block)
rooms2['BAÑO 3'] = translate(rooms1['BAÑO 3'], yoff=shift_block)
yPc = SOUTH_E - dP                       # Pepe closet top
pk2 = 1701.0 + shift_block               # pocket thickening ends (Pepe side)
rooms2['WALKING CLOSET (DORM. 3)'] = box(GE[1], yPc, 1281.6, SOUTH_E)
rooms2['DORMITORIO 3'] = Polygon([(EFX, nP0), (1024.2, nP0), (1024.2, pk2), (GE[1], pk2), (GE[1], yPc - T), (1296.6, yPc - T), (1296.6, SOUTH_E), (EFX, SOUTH_E)])

def metrics(name, P):
    pts = [(round(x, 1), round(y, 1)) for x, y in list(P.simplify(0.05).exterior.coords)[:-1]]
    P = Polygon(pts); xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    r = dict(name=name, pts=pts, area_m2=round(P.area / 1e4, 2), bbox=[min(xs), min(ys), max(xs), max(ys)],
             w=round(max(xs) - min(xs), 1), h=round(max(ys) - min(ys), 1), perim_m=round(P.length / 100, 2))
    c = P.centroid
    if not P.contains(c): c = P.representative_point()
    r['cx'] = round(c.x, 1); r['cy'] = round(c.y, 1); r['edges'] = []
    for i in range(len(pts)):
        a, b = pts[i], pts[(i + 1) % len(pts)]
        r['edges'].append(dict(a=list(a), b=list(b), len=round(math.hypot(b[0] - a[0], b[1] - a[1]), 1)))
    return r
rooms_out = [metrics(n, P) for n, P in rooms2.items()]

# ================= SYMBOLS =================
def inside(it, b): return all(b.contains(Point(p[0], p[1])) for p in it[1:])
def shifted(items, dy): return [[it[0]] + [[p[0], p[1] + dy] for p in it[1:]] for it in items]
K = 0.5523
def door_symbol(hinge, along, into, w):
    hx, hy = hinge
    L = (hx + into[0] * w, hy + into[1] * w); J = (hx + along[0] * w, hy + along[1] * w)
    c1 = (L[0] + along[0] * w * K, L[1] + along[1] * w * K); c2 = (J[0] + into[0] * w * K, J[1] + into[1] * w * K)
    return [['l', [hx, hy], [L[0], L[1]]], ['c', [L[0], L[1]], [c1[0], c1[1]], [c2[0], c2[1]], [J[0], J[1]]]]
src = v1['door_items_new']
drop_nw = [box(270, 325, 365, 425), box(285, 775, 380, 870), box(810, 415, 840, 770), box(360, 15, 390, 770), box(15, 400, 370, 425), box(895, 760, 1000, 870)]
east_zone = box(990, 520, 1792, 2040)
doors = [it for it in src if not any(inside(it, b) for b in drop_nw) and not inside(it, east_zone)]
# east symbols: block items slide; closet-door arrows follow their closet walls
blk = [it for it in src if inside(it, box(1000, 1238, 1769, 1678))]
doors += shifted(blk, shift_block)
doors += shifted([it for it in src if inside(it, box(1080, 1210, 1200, 1240))], (yAc + T) - 1214.3)   # WKC Anto door arrow
doors += shifted([it for it in src if inside(it, box(1080, 1675, 1200, 1700))], (yPc - T) - 1701.0)   # WKC Pepe door arrow
# new doors
doors += door_symbol((GW[0], DOOR_A[0]), (0, 1), (-1, 0), DOOR_A[1] - DOOR_A[0])          # bedroom, opens into the bedroom
doors += door_symbol((GW[0], DOOR_BATH[0]), (0, 1), (-1, 0), DOOR_BATH[1] - DOOR_BATH[0])  # bath, opens into the bath
doors += door_symbol((DOOR_HALL[1], OB[0]), (-1, 0), (0, -1), DOOR_HALL[1] - DOOR_HALL[0]) # Mini Hall entrance, opens into the hall
doors += door_symbol((GP[0], DOOR_GB[1]), (0, -1), (-1, 0), DOOR_GB[1] - DOOR_GB[0])       # guest bath, opens into the bath
# windows: keep V1 symbols except the east facade band below WKC Maggie; regenerate those
wins = [it for it in v1['win_items_new'] if not inside(it, box(EFX - 2, SUITE_S[1], 1792, SOUTH_E))]
for n, (a, b) in WIN.items():
    x0, x1 = EFX, 1790.0
    wins += [['l', [x0, a], [x1, a]], ['l', [x1, a], [x1, b]], ['l', [x1, b], [x0, b]], ['l', [x0, b], [x0, a]], ['l', [(x0 + x1) / 2, a], [(x0 + x1) / 2, b]]]
window_ids = []
for w in v1['windows_new']:
    w = dict(w)
    if w['t'] in WIN: w['y'] = round(sum(WIN[w['t']]) / 2, 1)
    window_ids.append(w)
furniture = [it for it in D['sym']['furniture'] if not inside(it, box(15, 15, 1015, 890)) and not inside(it, box(1000, 520, 1775, 2040)) and not inside(it, box(15, 880, 370, 1275))]
furniture += shifted([it for it in D['sym']['furniture'] if inside(it, box(1150, 1320, 1775, 1595))], shift_block)   # Baño Hijos fixtures slide with it

# ================= OPENINGS (door width labels) =================
ops1 = [o for o in D['openings'] if o['type'] in ('door', 'passage') and not (abs(o['gap'] - 100) < 1 and abs(o['a'][0] - 1019.2) < 1)]
def mid(o): return ((o['a'][0] + o['b'][0]) / 2, (o['a'][1] + o['b'][1]) / 2)
ops2 = [o for o in ops1 if not any(b.contains(Point(*mid(o))) for b in drop_nw) and not east_zone.contains(Point(*mid(o)))]
def sh(o, dy): return dict(a=[o['a'][0], round(o['a'][1] + dy, 1)], b=[o['b'][0], round(o['b'][1] + dy, 1)], gap=o['gap'], type=o['type'])
for o in ops1:
    m = mid(o)
    if 1212 < m[1] < 1703 and m[0] > 1000: ops2.append(sh(o, shift_block))
ops2 += [dict(a=[1111.7, yAc + T / 2], b=[1196.7, yAc + T / 2], gap=85.0, type='door'),
         dict(a=[1115.0, yPc - T / 2], b=[1190.0, yPc - T / 2], gap=75.0, type='door'),
         dict(a=[653.1, DOOR_A[0]], b=[653.1, DOOR_A[1]], gap=90.0, type='door'),
         dict(a=[653.1, DOOR_BATH[0]], b=[653.1, DOOR_BATH[1]], gap=80.0, type='door'),
         dict(a=[DOOR_HALL[0], (OB[0] + OB[1]) / 2], b=[DOOR_HALL[1], (OB[0] + OB[1]) / 2], gap=90.0, type='door'),
         dict(a=[1007.1, OF12[1]], b=[1007.1, SUITE_S[0]], gap=round(SUITE_S[0] - OF12[1], 1), type='passage'),
         dict(a=[(GP[0] + GP[1]) / 2, DOOR_GB[0]], b=[(GP[0] + GP[1]) / 2, DOOR_GB[1]], gap=75.0, type='door')]

out = dict(v1=dict(rooms=v1['rooms_new'], walls=v1['walls_new'], doors=v1['door_items_new'], windows=v1['win_items_new'],
                   window_ids=v1['windows_new'], furniture=D['sym']['furniture'], openings=ops1),
           v2=dict(rooms=rooms_out, walls=walls_out, doors=doors, windows=wins, window_ids=window_ids, furniture=furniture, openings=ops2),
           new_wall_axis=NEW_Y, k=round(k, 4))
json.dump(out, open('versions.json', 'w'), ensure_ascii=False)
for r in rooms_out: print(f"{r['name']:26s} {r['w']:6.1f} x {r['h']:6.1f}  {r['area_m2']:6.2f} m2  pts={len(r['pts'])}")
print('total v2', round(sum(r['area_m2'] for r in rooms_out), 2), ' total v1', round(sum(r['area_m2'] for r in v1['rooms_new']), 2))
R = unary_union([Polygon(r['pts']) for r in rooms_out]); W = unary_union([Polygon(w) for w in walls_out])
print('overlap room/wall cm2', round(R.intersection(W).area, 1), '| invalid walls', sum(1 for w in walls_out if not Polygon(w).is_valid))
rl = [Polygon(r['pts']) for r in rooms_out]
print('overlap room/room cm2', round(sum(rl[i].intersection(rl[j]).area for i in range(len(rl)) for j in range(i + 1, len(rl))), 1))
