import json, math
from shapely.geometry import Polygon, Point

D = json.load(open('plan_data.json'))
V = json.load(open('versions.json'))
RENAME = {
    'DORMITORIO PRINCIPAL (SUITE)': 'DORMITORIO MATRIMONIAL', 'DORMITORIO 4': 'DORMITORIO VISITAS',
    'DORMITORIO 2': 'DORMITORIO HIJO 1', 'DORMITORIO 3': 'DORMITORIO HIJO 2',
    'WALKING CLOSET (DORM. 2)': 'WKC HIJO 1', 'WALKING CLOSET (DORM. 3)': 'WKC HIJO 2',
    'ESTAR 2 + ESCALERA': 'FAMILY ROOM', 'BAÑO 2': 'BAÑO VISITAS', 'BAÑO 3': 'BAÑO HIJOS', 'BAÑO 4 (SUITE)': 'BAÑO MATRIMONIAL',
    'WALKING CLOSET (SUITE)': 'WKC GABRIEL', 'WALKING CLOSET (HALL)': 'WKC MAGGIE',
}
rn = lambda n: RENAME.get(n, n)

def f(v): return f"{v:.1f}".rstrip('0').rstrip('.')
def poly_path(pts): return 'M' + ' L'.join(f"{f(x)} {f(y)}" for x, y in pts) + ' Z'
def items_path(items):
    parts = []
    for it in items:
        if it[0] == 'l': parts.append(f"M{f(it[1][0])} {f(it[1][1])} L{f(it[2][0])} {f(it[2][1])}")
        elif it[0] == 'c':
            a, c1, c2, b = it[1], it[2], it[3], it[4]
            parts.append(f"M{f(a[0])} {f(a[1])} C{f(c1[0])} {f(c1[1])} {f(c2[0])} {f(c2[1])} {f(b[0])} {f(b[1])}")
        elif it[0] == 're':
            (x0, y0), (x1, y1) = it[1], it[2]; parts.append(f"M{f(x0)} {f(y0)} H{f(x1)} V{f(y1)} H{f(x0)} Z")
        elif it[0] == 'qu': parts.append('M' + ' L'.join(f"{f(p[0])} {f(p[1])}" for p in it[1:]) + ' Z')
    return ' '.join(parts)

kinds = {'OFICINA': 'oficina', 'DORMITORIO': 'dorm', 'BAÑO': 'bano', 'WALKING': 'closet', 'WKC': 'closet', 'ESTAR': 'estar', 'FAMILY': 'estar', 'HALL': 'hall', 'MINI HALL': 'hall', 'VESTÍBULO': 'hall'}
def build_rooms(rooms):
    out = []
    for i, r in enumerate(rooms):
        name = rn(r['name'])
        P = Polygon(r['pts'])
        kind = next((v for k, v in kinds.items() if name.startswith(k)), 'otro')
        edges = []
        for e in r['edges']:
            (ax, ay), (bx, by) = e['a'], e['b']
            mx, my = (ax + bx) / 2, (ay + by) / 2
            vert = abs(ax - bx) < 0.01
            lx, ly = mx, my
            for off in (14, -14):
                px_, py_ = (mx + off, my) if vert else (mx, my + off)
                if P.contains(Point(px_, py_)): lx, ly = px_, py_; break
            edges.append(dict(a=[ax, ay], b=[bx, by], len=e['len'], lx=round(lx, 1), ly=round(ly, 1), rot=-90 if vert else 0))
        out.append(dict(id='r' + str(i), name=name, kind=kind, pts=r['pts'], path=poly_path(r['pts']), area=r['area_m2'],
                        w=r['w'], h=r['h'], perim=r['perim_m'], cx=r['cx'], cy=r['cy'], bbox=r['bbox'], edges=edges))
    return out

def variant(vd, notes):
    return dict(rooms=build_rooms(vd['rooms']), wallsPath=' '.join(poly_path(w) for w in vd['walls']),
                windowsPath=items_path(vd['windows']), doorsPath=items_path(vd['doors']), furniturePath=items_path(vd['furniture']),
                windows=vd['window_ids'], openings=[o for o in vd['openings'] if o['type'] in ('door', 'passage')], setbacks=[], notes=notes)
# Ejes que el proyecto eliminó: eran cortes o entradas que se modificaron en obra.
QUITAR = {'11', '14'}
XQUITAR = [a['x'] for a in json.load(open('plan_data.json'))['axis_labels'] if a['t'] in QUITAR]
def FUERA(x0, x1):
    return abs(x0 - x1) < 1 and any(abs(x0 - x) < 3 for x in XQUITAR)

ny = V['new_wall_axis']
variants = dict(
    v1=variant(V['v1'], []),
    v2=variant(V['v2'], [dict(x=330, y=ny, rot=0, text=f'MURO ESTIMADO · eje {f(ny)} · ajustar'),
                         dict(x=291, y=1000, rot=-90, text='closet + cuna', line=False)]),
)
out = dict(W=D['W'], H=D['H'], variants=variants, stairsPath=items_path(D['sym']['stairs']),
           axesPath=' '.join(f"M{f(a)} {f(b)} L{f(c)} {f(d)}" for a, b, c, d in D['axes'] if not FUERA(a, c)),
           axisLabels=[a for a in D['axis_labels'] if a['t'] not in QUITAR], terrace=D['terrace'])
json.dump(out, open('svg_data.json', 'w'), ensure_ascii=False, separators=(',', ':'))
import os; print('bytes', os.path.getsize('svg_data.json'))
for k, vv in variants.items(): print(k, len(vv['rooms']), 'rooms', round(sum(r['area'] for r in vv['rooms']), 2), 'm2')
