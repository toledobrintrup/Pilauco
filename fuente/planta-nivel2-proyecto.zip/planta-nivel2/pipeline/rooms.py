import json, math
import numpy as np, cv2
from shapely.geometry import Polygon, LineString, box
from shapely.ops import unary_union

g = json.load(open('geom.json'))
L = json.load(open('layers_cm.json'))
walls = [Polygon(w['pts']) for w in g['walls']]
wall_union = unary_union(walls)

# --- find wall end caps: short edges (8..25 cm) ---
caps = []
for wi, w in enumerate(walls):
    pts = list(w.exterior.coords)[:-1]
    n = len(pts)
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        ln = math.hypot(b[0] - a[0], b[1] - a[1])
        if 8 <= ln <= 25:
            mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
            horiz = abs(a[1] - b[1]) < 0.01   # cap is horizontal -> wall runs vertical
            caps.append(dict(wi=wi, a=a, b=b, mid=mid, horiz=horiz, ln=ln))
print('caps', len(caps))

# --- pair caps facing each other along the same wall axis ---
openings = []
used = set()
for i, c1 in enumerate(caps):
    for j, c2 in enumerate(caps):
        if j <= i or c1['horiz'] != c2['horiz']: continue
        if c1['horiz']:   # vertical wall: same x, gap in y
            if abs(c1['mid'][0] - c2['mid'][0]) > 3: continue
            gap = abs(c1['mid'][1] - c2['mid'][1])
            seg = LineString([c1['mid'], c2['mid']])
        else:
            if abs(c1['mid'][1] - c2['mid'][1]) > 3: continue
            gap = abs(c1['mid'][0] - c2['mid'][0])
            seg = LineString([c1['mid'], c2['mid']])
        if gap < 5 or gap > 260: continue
        # no wall material in between (except touching ends)
        inner = seg.buffer(0.5)
        if wall_union.intersection(inner).area > 3.0 * 1.0 + 40: continue
        openings.append(dict(a=c1['mid'], b=c2['mid'], gap=round(gap, 1), horiz=not c1['horiz'], quad=[c1['a'], c1['b'], c2['b'], c2['a']]))
# dedupe: keep shortest openings per cap (a cap can pair with several)
openings.sort(key=lambda o: o['gap'])
final = []
capused = set()
for o in openings:
    ka, kb = (round(o['a'][0]), round(o['a'][1])), (round(o['b'][0]), round(o['b'][1]))
    if ka in capused or kb in capused: continue
    capused.add(ka); capused.add(kb); final.append(o)
# --- stubs: caps that nearly touch another wall's side (gap <= 15 cm) ---
from shapely.geometry import Point
def quad_of(o):
    q = o['quad']
    if math.hypot(q[1][0]-q[2][0], q[1][1]-q[2][1]) > math.hypot(q[1][0]-q[3][0], q[1][1]-q[3][1]):
        q = [q[0], q[1], q[3], q[2]]
    return q
blocked = unary_union([wall_union] + [Polygon(quad_of(o)) for o in final])
stubs = []
for c in caps:
    k = (round(c['mid'][0]), round(c['mid'][1]))
    if k in capused: continue
    poly = walls[c['wi']]
    if c['horiz']: dirs = [(0, 1), (0, -1)]
    else: dirs = [(1, 0), (-1, 0)]
    for dx, dy in dirs:
        if poly.contains(Point(c['mid'][0] + dx * 2, c['mid'][1] + dy * 2)): continue  # inward
        probe = LineString([(c['mid'][0] + dx * 1, c['mid'][1] + dy * 1), (c['mid'][0] + dx * 130, c['mid'][1] + dy * 130)])
        inter = probe.intersection(blocked)
        if inter.is_empty: continue
        # distance to first hit
        d = probe.project(inter.representative_point()) if inter.geom_type != 'Point' else probe.project(inter)
        dist = min(Point(c['mid']).distance(gm) for gm in (inter.geoms if hasattr(inter, 'geoms') else [inter]))
        L2 = dist + 1
        q = [c['a'], c['b'], (c['b'][0] + dx * L2, c['b'][1] + dy * L2), (c['a'][0] + dx * L2, c['a'][1] + dy * L2)]
        stubs.append(dict(quad=q, gap=round(dist, 1), a=c['mid'], b=(c['mid'][0] + dx * L2, c['mid'][1] + dy * L2)))
print('stubs', len(stubs))
for s in stubs: print('  stub', [round(v, 1) for v in s['a']], s['gap'])
json.dump(stubs, open('stubs.json', 'w'))
print('openings', len(final))
for o in final: print(o)
json.dump(final, open('openings.json', 'w'))

# --- rasterize: walls + closures -> rooms ---
PX = 4; OFF = 20; W, H = 1790, 2177
img = np.zeros((H * PX + 2 * PX * OFF, W * PX + 2 * PX * OFF), np.uint8)
def px(v): return int(round((v + OFF) * PX))
for w in g['walls']:
    cv2.fillPoly(img, [np.array([(px(x), px(y)) for x, y in w['pts']], np.int32)], 255)
for o in final:
    q = o['quad']
    # order quad properly (c1.a, c1.b, then nearest of c2)
    if math.hypot(q[1][0]-q[2][0], q[1][1]-q[2][1]) > math.hypot(q[1][0]-q[3][0], q[1][1]-q[3][1]):
        q = [q[0], q[1], q[3], q[2]]
    cv2.fillPoly(img, [np.array([(px(x), px(y)) for x, y in q], np.int32)], 255)
for s in stubs:
    cv2.fillPoly(img, [np.array([(px(x), px(y)) for x, y in s['quad']], np.int32)], 255)
for k in ['(0.28, 0.53)', '(0.43, 0.5)', '(0.23, 0.53)']:
    for it in L.get(k, []):
        if it[0] == 'l':
            cv2.line(img, (px(it[1][0]), px(it[1][1])), (px(it[2][0]), px(it[2][1])), 255, 1)
img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
inv = (img == 0).astype(np.uint8)
n, lab, stats, cent = cv2.connectedComponentsWithStats(inv, connectivity=4)
rooms = []
for i in range(1, n):
    x, y, w, h, area = stats[i]
    if x == 0 or y == 0 or x + w >= img.shape[1] or y + h >= img.shape[0]: continue
    area_cm2 = area / PX / PX
    if area_cm2 < 5000: continue
    comp = (lab == i).astype(np.uint8)
    cnts, _ = cv2.findContours(comp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnt = max(cnts, key=cv2.contourArea)
    approx = cv2.approxPolyDP(cnt, 1.5, True)
    pts = [(round(p[0][0] / PX - OFF, 1), round(p[0][1] / PX - OFF, 1)) for p in approx]
    rooms.append(dict(pts=pts, area_m2=round(float(area_cm2) / 1e4, 2),
                      bbox=[float(v) for v in (x / PX - OFF, y / PX - OFF, w / PX, h / PX)],
                      cx=float(cent[i][0] / PX - OFF), cy=float(cent[i][1] / PX - OFF)))
rooms.sort(key=lambda r: (r['bbox'][1], r['bbox'][0]))
for r in rooms:
    print('ROOM bbox', [round(v) for v in r['bbox']], 'area', r['area_m2'], 'npts', len(r['pts']))
json.dump(rooms, open('rooms_raw.json', 'w'))
vis = np.full(img.shape + (3,), 255, np.uint8)
vis[img > 0] = (0, 0, 0)
ext = (lab == lab[5, 5])
vis[ext] = (200, 230, 255)
cv2.imwrite('raster_vis.png', cv2.resize(vis, None, fx=0.15, fy=0.15, interpolation=cv2.INTER_AREA))
