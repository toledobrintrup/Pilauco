# -*- coding: utf-8 -*-
"""Nivel 2: aplica el mismo criterio de puertas que el nivel 1 (0,90 en lo que pisa
gente, 0,80 en closets) sobre las puertas que ya dibujo el arquitecto en v1 y v2.

Posicion: se ensancha cada puerta de forma simetrica respecto a su centro actual
(cambio minimo, sin riesgo de invadir una esquina), salvo en los dos casos donde se
sondeo el muro real y sobraba margen para corregir una puerta muy descentrada
(Baño 2 / Vestibulo Visitas y Baño Matrimonial / Mini Hall, las dos en Version 2).

Se deja sin tocar: las puertas vidriadas a exterior (van con las ventanas) y los dos
pasos abiertos sin hoja entre Family Room y Hall Dormitorios -- no se inventa una
puerta donde el plano original no dibujo ninguna; de esos si se eliminan los
duplicados casi identicos que hacian que la cota se imprimiera dos veces encimada.
"""
import json, math
from shapely.geometry import Polygon, box as _box, Point
from shapely.ops import unary_union

def _puerta(A, B, lado):
    w = math.hypot(B[0]-A[0], B[1]-A[1])
    d = {'norte':(0,-1),'sur':(0,1),'oriente':(1,0),'poniente':(-1,0)}[lado]
    Tp = (A[0]+d[0]*w, A[1]+d[1]*w); k = 0.5523*w
    u = ((Tp[0]-A[0])/w, (Tp[1]-A[1])/w); v = ((B[0]-A[0])/w, (B[1]-A[1])/w)
    return [['l', [A[0],A[1]], [Tp[0],Tp[1]]],
            ['c', [Tp[0],Tp[1]], [Tp[0]+v[0]*k,Tp[1]+v[1]*k], [B[0]+u[0]*k,B[1]+u[1]*k], [B[0],B[1]]]]

TB = 15.0

EDITS = [
    dict(a=[355.4,1278.1], b=[280.4,1278.1], gap=75.0, ngap=90.0, hoja=True,  versiones=['v1','v2'], hacia='y<'),
    dict(a=[1152.1,1420.5], b=[1152.1,1495.5], gap=75.0, ngap=90.0, hoja=True, versiones=['v1'], hacia='BAÑO 3'),
    dict(a=[1115.0,1708.5], b=[1190.0,1708.5], gap=75.0, ngap=80.0, hoja=False, versiones=['v1']),
    dict(a=[1007.1,594.5], b=[1007.1,679.4], gap=84.9, ngap=90.0, hoja=True, versiones=['v1'], hacia='BAÑO 4'),
    dict(a=[824.5,517.2], b=[824.5,432.2], gap=85.0, ngap=80.0, hoja=False, versiones=['v1']),
    dict(a=[840.7,412.8], b=[925.7,412.8], gap=85.0, ngap=80.0, hoja=False, versiones=['v1','v2']),
    dict(a=[1111.7,1206.8], b=[1196.7,1206.8], gap=85.0, ngap=80.0, hoja=False, versiones=['v1']),
    dict(a=[374.9,1727.3], b=[374.9,1820.5], gap=92.2, ngap=90.0, hoja=True, versiones=['v1','v2'], hacia='DORMITORIO 4'),
    dict(a=[1152.1,1242.1], b=[1152.1,1317.1], gap=75.0, ngap=90.0, hoja=True, versiones=['v2'], hacia='BAÑO 3'),
    dict(a=[1111.7,980.281], b=[1196.7,980.281], gap=85.0, ngap=80.0, hoja=False, versiones=['v2']),
    dict(a=[1115.0,1578.300], b=[1190.0,1578.300], gap=75.0, ngap=80.0, hoja=False, versiones=['v2']),
    dict(a=[212.6,1180.0], b=[212.6,1255.0], gap=75.0, ngap=90.0, hoja=True, versiones=['v2'],
         na=[212.6,1256.0], nb=[212.6,1166.0], hacia='BAÑO 2'),
    dict(a=[653.1,600.0], b=[653.1,680.0], gap=80.0, ngap=90.0, hoja=True, versiones=['v2'],
         na=[653.1,616.0], nb=[653.1,706.0], hacia='BAÑO 4'),
]

DEDUPE = [
    ('v1', [1012.2,1327.8]), ('v1', [1007.1,1507.6]),
    ('v2', [1012.2,1149.4]), ('v2', [1007.1,1329.2]),
]

def cerca(p, q, tol=6):
    return abs(p[0]-q[0]) < tol and abs(p[1]-q[1]) < tol

def procesa(k, vd):
    walls = [Polygon(w).buffer(0) for w in vd['walls']]
    W = unary_union(walls)
    rooms_geo = unary_union([Polygon(r['pts']).buffer(0) for r in vd['rooms']])
    rellenos, cortes, nuevas_hojas, limpiar = [], [], [], []
    ops = vd['openings']
    cambiadas = 0

    for e in EDITS:
        if k not in e['versiones']: continue
        idx = None
        for i, o in enumerate(ops):
            if o['type'] == 'door' and cerca(o['a'], e['a']) and cerca(o['b'], e['b']):
                idx = i; break
        if idx is None:
            print(f'  [{k}] AVISO: no encontre {e["a"]}-{e["b"]}'); continue
        a, b = e['a'], e['b']
        vert = abs(a[0]-b[0]) < 1
        wall_coord = a[0] if vert else a[1]
        if 'na' in e:
            na, nb = e['na'], e['nb']
        else:
            old_c = (a[1]+b[1])/2 if vert else (a[0]+b[0])/2
            half = e['ngap']/2
            lo, hi = old_c-half, old_c+half
            na = [wall_coord, hi] if vert else [hi, wall_coord]
            nb = [wall_coord, lo] if vert else [lo, wall_coord]

        old_lo, old_hi = (min(a[1],b[1]), max(a[1],b[1])) if vert else (min(a[0],b[0]), max(a[0],b[0]))
        new_lo, new_hi = (min(na[1],nb[1]), max(na[1],nb[1])) if vert else (min(na[0],nb[0]), max(na[0],nb[0]))
        pad = 1.0
        if vert:
            rellenos.append(_box(wall_coord-TB/2-pad, old_lo-pad, wall_coord+TB/2+pad, old_hi+pad))
            cortes.append(_box(wall_coord-TB/2, new_lo, wall_coord+TB/2, new_hi))
        else:
            rellenos.append(_box(old_lo-pad, wall_coord-TB/2-pad, old_hi+pad, wall_coord+TB/2+pad))
            cortes.append(_box(new_lo, wall_coord-TB/2, new_hi, wall_coord+TB/2))

        cx, cy = (a[0]+b[0])/2, (a[1]+b[1])/2
        limpiar.append((cx-95, cy-95, cx+95, cy+95))

        if e['hoja']:
            hacia = e.get('hacia', '')
            objetivo = None
            if hacia == 'y<':
                objetivo = 'norte'   # solo se usa en muros horizontales
            else:
                objetivo = next((r['name'] for r in vd['rooms'] if hacia in r['name']), None)
            lados = ['poniente','oriente'] if vert else ['norte','sur']
            candidatos = {}
            for lado in lados:
                w_ = math.hypot(nb[0]-na[0], nb[1]-na[1])
                dd = {'norte':(0,-1),'sur':(0,1),'oriente':(1,0),'poniente':(-1,0)}[lado]
                tip = (na[0]+dd[0]*w_, na[1]+dd[1]*w_)
                candidatos[lado] = Point((na[0]+nb[0]+tip[0])/3, (na[1]+nb[1]+tip[1])/3)
            mejor = None
            if objetivo == 'norte' and 'norte' in candidatos:
                mejor = 'norte'
            elif isinstance(objetivo, str) and objetivo not in ('norte',):
                room_poly = next((Polygon(r['pts']) for r in vd['rooms'] if r['name']==objetivo), None)
                if room_poly is not None:
                    for lado, probe in candidatos.items():
                        if room_poly.buffer(2).contains(probe): mejor = lado; break
            if mejor is None:
                for lado, probe in candidatos.items():
                    if rooms_geo.buffer(2).contains(probe): mejor = lado; break
            if mejor is None: mejor = lados[0]
            nuevas_hojas += _puerta(na, nb, mejor)

        ops[idx]['a'] = na; ops[idx]['b'] = nb; ops[idx]['gap'] = e['ngap']
        cambiadas += 1

    # Deja solo 2 pasos reales (norte y sur) de los 4 casi-duplicados que el
    # detector de vanos genero para el mismo hueco fisico (medido desde sus dos
    # esquinas). Agrupa por cercania y conserva uno por grupo.
    idx_hall = [i for i, o in enumerate(ops)
                if 1000 <= o['a'][0] <= 1020 and any(v == k for v, p in DEDUPE)]
    grupos = []
    for i in idx_hall:
        o = ops[i]; c = ((o['a'][1]+o['b'][1])/2)
        for g in grupos:
            if abs(g['c']-c) < 15: g['idx'].append(i); break
        else:
            grupos.append(dict(c=c, idx=[i]))
    quitar_idx = set()
    for g in grupos:
        for i in g['idx'][1:]: quitar_idx.add(i)
    vd['openings'] = [o for i, o in enumerate(ops) if i not in quitar_idx]

    Wnew = unary_union([W] + rellenos)
    Wnew = Wnew.difference(unary_union(cortes))
    out_walls = []
    geoms = [Wnew] if Wnew.geom_type == 'Polygon' else list(Wnew.geoms)
    for g in geoms:
        if g.geom_type != 'Polygon': continue
        q = g.simplify(0.05)
        out_walls.append([[round(x,1),round(y,1)] for x,y in list(q.exterior.coords)[:-1]])
        for h in q.interiors:
            out_walls.append([[round(x,1),round(y,1)] for x,y in list(h.coords)[:-1]])
    vd['walls'] = out_walls

    def fuera_de(items):
        out = []
        for it in items:
            pts = [p for p in it[1:] if isinstance(p, list)]
            if pts and any(all(bx0<=p[0]<=bx1 and by0<=p[1]<=by1 for p in pts) for bx0,by0,bx1,by1 in limpiar):
                continue
            out.append(it)
        return out
    vd['doors'] = fuera_de(vd['doors']) + nuevas_hojas

    print(f'  [{k}] {cambiadas} puertas cambiadas, {len(quitar_idx)} duplicados eliminados, muros: {len(walls)} -> {len(out_walls)} anillos')
    return vd

if __name__ == '__main__':
    V = json.load(open('versions.json'))
    for k in ('v1','v2'):
        print(f'=== {k} ===')
        V[k] = procesa(k, V[k])
    json.dump(V, open('versions.json','w'))
    print('versions.json actualizado')
